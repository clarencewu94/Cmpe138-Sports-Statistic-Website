Brandon Nguyen
008750768
brandonwnguyen@gmail.com


Instructions
Open zip file containing the project.
Open the terminal and change directory to the folder of this readme.
use the command:
python app.py
Open a browser and use 127.0.0.1:5000 as the URL to run.